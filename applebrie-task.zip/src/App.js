import React, {useRef} from 'react';
import { Route, Routes, BrowserRouter} from "react-router-dom";
import {createMemoryHistory } from "history";
import Header from "./view/layouts/header";
import Footer from "./view/layouts/footer";
import Users from "./view/pages/users";
import Posts from "./view/pages/posts";
import HomePage from "./view/pages/homePage";
import routs from "./routing/routs";
import "./assets/scss/main.scss"

function App() {
  const history = createMemoryHistory();
  const pages = useRef({
    "/posts": <Posts />,
    "/users": <Users />,
    "/":  <HomePage />
  })
  return (
      <BrowserRouter location={history.location} navigator={history}>
        <Header />
        <main className="main-layout">
          <Routes>
            {
              routs.map(item =>(<Route key={item.id} path={item.path} element={pages.current[item.path]}/>))
            }
          </Routes>
        </main>
        <Footer />
      </BrowserRouter>
  );
}

export default App;
