import React from "react";
import {NavLink} from "react-router-dom";
import routs from "../../routing/routs";

function Navigation() {
    return (
        <nav className="navigation">
            <ul className="navigation-list">
                {
                    routs.map(route => (
                        <li className="navigation-list-item" key={route.id}>
                            <NavLink to={route.path}
                                     className={({isActive}) => isActive ? "active" : ""}
                            >
                                <div className="icon">{route.icon}</div>
                                {route.name}
                            </NavLink>
                        </li>
                    ))
                }
            </ul>
        </nav>
    )
}

export default Navigation