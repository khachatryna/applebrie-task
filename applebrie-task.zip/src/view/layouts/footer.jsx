import React from "react";

function Footer() {
    return (
        <footer>
            &copy; All rights reserved
        </footer>
    )
}

export default Footer;