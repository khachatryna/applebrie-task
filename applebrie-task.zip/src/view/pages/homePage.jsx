import React from "react";

function HomePage() {
    return (
        <div className="homepage">
            <h1>Welcome Everyone</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Id temporibus perferendis necessitatibus numquam amet impedit explicabo? Debitis quasi ullam aperiam!</p>
        </div>
    )
}

export default HomePage