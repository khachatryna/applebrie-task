import React from "react";

function Users() {
    return (
        <div className="users">

        </div>
    )
}

export default Users