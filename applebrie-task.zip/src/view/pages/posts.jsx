import React from "react";

function Posts() {
    return (
        <div className="posts">

        </div>
    )
}

export default Posts